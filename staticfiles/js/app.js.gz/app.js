const projectMenu = document.querySelector('.arrow-container')
const projectView = document.querySelector('#sectiontwo')

projectMenu.addEventListener('click', function(e){
    projectView.classList.toggle('sectionTwoslide')
    console.log('bitch')
})